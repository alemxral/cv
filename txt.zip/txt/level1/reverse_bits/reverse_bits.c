/* reverse_bits: reverse the order of bits in a byte
 * - takes an 8-bit value (octet)
 * - extracts bits from right to left (LSB to MSB)
 * - builds result from left to right (MSB to LSB)
 * - returns the reversed byte
 * 
 * Examples:
 *   Input:  0b01000001 (0x41, decimal 65, 'A')
 *   Output: 0b10000010 (0x82, decimal 130)
 *   
 *   Input:  0b00100110 (0x26, decimal 38)
 *   Output: 0b01100100 (0x64, decimal 100)
 *   
 *   Input:  0b11111111 (0xFF, decimal 255)
 *   Output: 0b11111111 (0xFF, decimal 255) — palindrome
 *   
 *   Input:  0b00000001 (0x01, decimal 1)
 *   Output: 0b10000000 (0x80, decimal 128)
 *   
 *   Input:  0b10000000 (0x80, decimal 128)
 *   Output: 0b00000001 (0x01, decimal 1)
 * 
 * Method: extract each bit from right and shift result left
 */
unsigned char	reverse_bits(unsigned char octet)
{
	int		i = 8;              /* counter: process 8 bits */
	unsigned char	res = 0;    /* result starts empty (0b00000000) */

	while (i > 0)               /* loop 8 times (once per bit) */
	{
		/* res = res * 2: shift result left by 1 bit (make room for next bit)
		 * (octet % 2): extract the rightmost bit of octet (0 or 1)
		 * add extracted bit to result as new rightmost bit */
		res = res * 2 + (octet % 2);
		
		/* octet = octet / 2: shift octet right by 1 bit (discard processed bit)
		 * next iteration will process the next bit */
		octet = octet / 2;
		
		i--;                    /* decrement counter */
	}
	return (res);               /* return reversed byte */
}

