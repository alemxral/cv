#include <stdlib.h>
#include <stdio.h>


// int	max(int* tab, unsigned int len)
// {
// 	if (len == 0)
// 		return (0);
// 	int res = tab[0];
// 	for (unsigned int i = 0; i < len; i += 1)
// 	{
// 		if (res < tab[i])
// 			res = tab[i];
// 	}
// 	return (res);
// }


int	max(int* tab, unsigned int len)
{



	unsigned int i = 1;
	int max = tab[0];


	if (len == 0)
		return (0);

	
	if(!(tab[0]>=0)&&!(tab[0]<0))
		return(0);

	while(i<len)
	
	{
		if (max < tab[i])
		{max = tab[i];}
		i++;
	}
	return (max);
}


int main(int argc, char **argv)
{
    if (argc < 3)
        return(0);
    int *tab = malloc(sizeof(int) * (argc - 1));
    
    printf("max( {");
    for (int i = 2; i < argc; i++)
    {
        printf("%s", argv[i]);
        if (i != argc - 1)
            printf(";");
        tab[i - 2] = atoi(argv[i]);
    }
    printf("} , %s) = %d\n", argv[1], max(tab, atoi(argv[1])));
    // printf("max(\"%s\") = %d\n", argv[1], is_power_of_2(atoi(argv[1])));
    return(0);
}
