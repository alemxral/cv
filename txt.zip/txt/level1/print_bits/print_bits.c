#include <unistd.h>

/*
** print_bits: Prints the binary representation of a byte (8 bits)
** 
** Prints bits from most significant (bit 7) to least significant (bit 0).
** Each bit is printed as '0' or '1'.
**
** Examples:
**   Input: 2 (0x02, 0b00000010)     → Output: "00000010"
**   Input: 255 (0xFF, 0b11111111)   → Output: "11111111"
**   Input: 65 (0x41, 0b01000001)    → Output: "01000001"
**   Input: 128 (0x80, 0b10000000)   → Output: "10000000"
**   Input: 0 (0x00, 0b00000000)     → Output: "00000000"
**
** Method:
**   We extract each bit starting from bit 7 (leftmost) down to bit 0 (rightmost)
**   by shifting right and masking with 1.
*/
void print_bits(unsigned char octet)
{
	int	i = 8;              // Start with 8 (will decrement to 7, 6, 5... 0)
	unsigned char 	bit;    // Will hold '0' or '1' character to print

	while (i--)                     // Loop 8 times: i=7,6,5,4,3,2,1,0
	{
		// Extract the i-th bit:
		//   octet >> i        : Shift right by i positions (moves bit i to position 0)
		//   ... & 1           : Mask with 1 to isolate just that bit (result is 0 or 1)
		//   ... + '0'         : Convert number 0 or 1 to character '0' or '1'
		bit = (octet >> i & 1) + '0';
		write(1, &bit, 1);          // Print the character
	}
}