#include <unistd.h>

/* swap_bits: swap the high 4 bits and low 4 bits of a byte
 * - takes an 8-bit value (octet)
 * - moves the high nibble (bits 7-4) to the low nibble position (bits 3-0)
 * - moves the low nibble (bits 3-0) to the high nibble position (bits 7-4)
 * - returns the result
 * 
 * Example: 
 *   input:  0b01000001 (0x41, 'A')
 *           high nibble: 0100, low nibble: 0001
 *   output: 0b00010100 (0x14)
 *           high nibble: 0001, low nibble: 0100
 */
unsigned char	swap_bits(unsigned char octet)
{
    /* (octet >> 4): shift right by 4 → move high nibble to low nibble position
     *               example: 0b01000001 >> 4 = 0b00000100
     * 
     * (octet << 4): shift left by 4 → move low nibble to high nibble position
     *               example: 0b01000001 << 4 = 0b00010000
     * 
     * | (bitwise OR): combine both results
     *               0b00000100 | 0b00010000 = 0b00010100
     */
    return ((octet >> 4) | (octet << 4));
}
