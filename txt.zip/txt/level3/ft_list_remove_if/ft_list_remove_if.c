#include <stdlib.h>

// Define the linked list structure
typedef struct      s_list
{
    struct s_list   *next;  // Pointer to next node
    void            *data;  // Pointer to node's data
}                   t_list;

// int cmp(void *a, void *b);
// Example cmp function signature that compares two data pointers
// Returns 0 if they match/are equal, non-zero otherwise
// Example: int cmp(void *a, void *b) { return (*(int*)a - *(int*)b); }

// Removes all nodes from linked list whose data matches data_ref (using cmp function)
// begin_list: pointer to pointer to first node (allows modification of head)
// data_ref: reference data to compare against
// cmp: function pointer - comparison function that returns 0 when data matches
//      Takes two void* pointers, returns int (0 = match, non-zero = no match)
//
// ALGORITHM STEPS:
// 1. Check if list is empty or NULL → return (base case)
// 2. Get current node to examine
// 3. Compare current node's data with data_ref using cmp function
// 4a. IF MATCH (cmp returns 0):
//     - Point head to next node (bypass current)
//     - Free current node memory
//     - Recursively call same function on new head (check consecutive matches)
// 4b. IF NO MATCH:
//     - Keep current node
//     - Recursively call function on rest of list (cur->next)
void ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)(void *, void *))
{
	// STEP 1: Base case - empty list or NULL pointer
	if (begin_list == NULL || *begin_list == NULL)
		return;

	// STEP 2: Get current node to examine
	t_list *cur = *begin_list;

	// STEP 3: Compare current node's data with data_ref
	if (cmp(cur->data, data_ref) == 0)
	{
		// STEP 4a: MATCH found - remove this node
		
		// Update head to next node (skip/bypass current node)
		*begin_list = cur->next;
		
		// Free the memory of removed node
		free(cur);
		
		// Recursively check new head (handles consecutive matching nodes)
		// Example: if list is [5->5->3], after removing first 5, 
		// we need to check if new head (second 5) also matches
		ft_list_remove_if(begin_list, data_ref, cmp);
	}
	else
	{
		// STEP 4b: NO MATCH - keep current node, check rest of list
		
		// Current node is fine, recursively check remaining nodes
		// Pass address of cur->next so we can modify the list from that point
		ft_list_remove_if(&cur->next, data_ref, cmp);
	}
}