/*
** REV_WSTR - Print Words in Reverse Order
** 
** Takes a string and prints its words in reverse order.
** Words are separated by spaces/tabs.
** 
** Examples:
**   ./rev_wstr "Hello world"     → "world Hello"
**   ./rev_wstr "   foo bar   "   → "bar foo"
**   ./rev_wstr "a b c"            → "c b a"
** 
** Algorithm:
** 1. Start from end of string
** 2. Find each word by locating its boundaries (backwards)
** 3. Print the word (forwards)
** 4. Continue until beginning of string
*/

#include <unistd.h>

int main(int ac, char **av)
{
    int i;      // Current position in string (moves backwards)
    int start;  // Start index of current word
    int end;    // End index of current word

    // Check if exactly one argument
    if (ac == 2)
    {
        // Find the end of the string
        i = 0;
        while (av[1][i])
            i++;
        // Now i points to '\0', move back to last character
        
        // Process string backwards, word by word
        while (i >= 0)
        {
            // Skip trailing spaces (move backwards past spaces)
            while (i >= 0 && av[1][i] == ' ')
                i--;
            
            // Mark end of current word
            end = i;
            
            // Find start of current word (move backwards to space or beginning)
            while (i >= 0 && av[1][i] != ' ')
                i--;
            
            // Mark start of current word (one position after space/beginning)
            start = i + 1;
            
            // Print the word if we found one (start <= end means valid word)
            if (start <= end)
            {
                // Print character by character from start to end
                while (start <= end)
                {
                    write(1, &av[1][start], 1);
                    start++;
                }
                
                // Print space between words (but not after last word)
                if (i >= 0)  // If not at beginning, more words to come
                    write(1, " ", 1);
            }
        }
    }
    
    // Always print newline at the end
    write(1, "\n", 1);
    return (0);
}

/*
** Example trace for: ./rev_wstr "Hello world foo"
** 
** Initial: av[1] = "Hello world foo"
**          i = 0
** 
** Step 1: Find end of string
**   Loop: i = 0, 1, 2, ..., 14, 15 (at '\0')
**   Result: i = 15
** 
** Step 2: Process backwards
** 
**   Iteration 1: Find "foo"
**     Skip spaces: i = 15 → 14 (no spaces)
**     end = 14 (at 'o')
**     Find start: i = 14, 13, 12, 11 (space found)
**     start = 12 (at 'f')
**     Print: "foo"
**     i >= 0, so print " "
**     State: i = 11 (at space before "foo")
** 
**   Iteration 2: Find "world"
**     Skip spaces: i = 11 → 10 (skip one space)
**     end = 10 (at 'd')
**     Find start: i = 10, 9, 8, 7, 6, 5 (space found)
**     start = 6 (at 'w')
**     Print: "world"
**     i >= 0, so print " "
**     State: i = 5 (at space before "world")
** 
**   Iteration 3: Find "Hello"
**     Skip spaces: i = 5 → 4 (skip one space)
**     end = 4 (at 'o')
**     Find start: i = 4, 3, 2, 1, 0, -1 (reached beginning)
**     start = 0 (at 'H')
**     Print: "Hello"
**     i < 0, so DON'T print space
**     State: i = -1
** 
**   Exit loop (i < 0)
** 
** Final output: "foo world Hello\n"
*/
