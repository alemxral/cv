/*
** FPRIME - Prime Factorization
** 
** Problem: Print the prime factorization of a number
** 
** Examples:
**   fprime 225225  → "3*3*5*5*7*11*13"
**   fprime 8333325 → "3*3*5*5*7*11*13*37"
**   fprime 9539    → "9539" (already prime)
**   fprime 1       → "1"
** 
** Algorithm:
** 1. Start with factor = 2 (smallest prime)
** 2. If current factor divides n and is prime:
**    - Print the factor
**    - Divide n by factor
**    - Try same factor again (for repeated factors like 2*2*2)
** 3. If factor doesn't divide n:
**    - Move to next factor
** 4. Continue until n is fully factored
*/

#include <stdio.h>
#include <stdlib.h>

/*
** is_prime: Check if a number is prime
** 
** A prime number is only divisible by 1 and itself.
** We check if n is divisible by any number from 2 to n-1.
** 
** Parameters:
**   n - number to check
** 
** Returns:
**   1 if prime, 0 if not prime
** 
** Examples:
**   is_prime(2)  → 1 (prime)
**   is_prime(7)  → 1 (prime)
**   is_prime(8)  → 0 (not prime, divisible by 2 and 4)
**   is_prime(11) → 1 (prime)
*/
int		is_prime(int n)
{
	int i = 2;

	/* Try dividing by all numbers from 2 to n-1 */
	while (i < n)
	{
		/* If n is divisible by i, it's not prime */
		if (n % i == 0)
		{
			return (0);
		}
		++i;
	}
	/* If we get here, n is prime */
	return (1);
}

/*
** fprime: Print prime factorization of a number
** 
** Prints all prime factors separated by '*'
** 
** Parameters:
**   str - string representation of the number to factor
** 
** How it works:
**   1. Convert string to integer
**   2. Try each factor starting from 2
**   3. If factor divides n AND is prime:
**      - Print it
**      - Divide n by factor (to remove this factor)
**      - Keep same factor (to find repeated factors like 2*2*2)
**   4. If factor doesn't work, try next one
** 
** Example trace for fprime("12"):
**   n=12, factor=2: 12%2=0 and is_prime(2)=1 → print "2", n=12/2=6
**   n=6,  factor=2: 6%2=0 and is_prime(2)=1  → print "*2", n=6/2=3
**   n=3,  factor=2: 3%2≠0 → factor++
**   n=3,  factor=3: 3%3=0 and is_prime(3)=1  → print "*3", n=3/3=1
**   n=1,  factor=3: 3>1 → stop
**   Output: "2*2*3"
*/
void	fprime(char *str)
{
	int n = atoi(str);        /* Convert string to integer */
	int factor = 2;           /* Start with smallest prime */
	int first = 1;            /* Flag to track first factor (no '*' before it) */

	/* Special case: 1 has no prime factors */
	if (n == 1)
	{
		printf("1");
	}

	/* Try all factors from 2 up to n */
	while (factor <= n)
	{
		/* Check if factor divides n AND is prime */
		if (n % factor == 0 && is_prime(factor))
		{
			/* Print the factor */
			if (first == 1)
			{
				printf("%d", factor);  /* First factor: no '*' before it */
			}
			else
			{
				printf("*%d", factor); /* Subsequent factors: add '*' separator */
			}
			first = 0;            /* No longer the first factor */
			n = n / factor;       /* Divide n by this factor */
			/* Don't increment factor! Try same factor again for repeated primes */
		}
		else
		{
			/* Factor doesn't work, try next one */
			++factor;
		}
	}
}

/*
** main: Entry point
** 
** Usage: ./fprime <number>
** 
** If exactly one argument is provided, factorize it.
** Always print a newline at the end.
*/
int		main(int argc, char **argv)
{
	/* Check if exactly one argument provided */
	if (argc == 2)
	{
		fprime(argv[1]);
	}

	printf("\n");
	return (0);
}