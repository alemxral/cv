
#include <stdlib.h>
#include <stdio.h>

int		absolute_value(int nbr)
{
	if (nbr < 0)
		return (-nbr);
	return (nbr);
}

int		get_len(int nbr)
{
	int len = 0;
	if (nbr <= 0)
		++len;
	while (nbr != 0)
	{
		++len;
		nbr = nbr / 10;
	}
	return (len);
}

char	*ft_itoa(int n)
{
	char *result;
	int len;
	char c;
	long nbr=(long)n;

	len = get_len(nbr);
	result = malloc(sizeof(char) * (len + 1));

	result[len] = '\0';

	if (nbr < 0)
	{

	result[0] = '-';
	
	}
	
	else if (nbr == 0)
		result[0] = '0';

	while (nbr != 0)
	{
		len--;
		c = absolute_value(nbr) % 10 + '0';
		result[len] = c;
		nbr = nbr / 10;
	}
	return (result);
}

int main(int ac, char **av)
{
	if (ac == 2)
	{
		int num = atoi(av[1]);
		char *result = ft_itoa(num);
		printf("Input: %d\n", num);
		printf("Output: %s\n", result);
		free(result);
	}
	else
	{
		printf("Usage: %s <number>\n", av[0]);
	}
	return (0);
}
