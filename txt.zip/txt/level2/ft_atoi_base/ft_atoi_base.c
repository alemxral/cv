/*
** get_digit: Convert a character to its numeric value in a given base
** 
** Parameters:
**   c               - Character to convert (e.g., '5', 'a', 'F')
**   digits_in_base  - The base (2 to 16 supported)
**
** Returns:
**   The numeric value (0-15) if valid in this base
**   -1 if the character is invalid for this base
**
** Examples:
**   get_digit('5', 10)  → 5  (valid in base 10)
**   get_digit('9', 8)   → -1 (invalid in base 8, octal only goes 0-7)
**   get_digit('a', 16)  → 10 (valid in base 16, hex)
**   get_digit('f', 10)  → -1 (invalid in base 10)
*/
int get_digit(char c, int digits_in_base)
{
	char	digits[] = "0123456789abcdef";
	int		i = 0;

	// Convert uppercase to lowercase
	if (c >= 'A' && c <= 'F')
		c = c + ('a' - 'A'); // or c += 32;

	// Search for character in the digits string
	while (i < digits_in_base && digits[i])
	{
		if (digits[i] == c)
			return (i);  // Found! Return its position (= its value)
		i++;
	}

	return (-1);  // Not found or out of base range
}

/*
** ft_atoi_base: Convert a string to an integer in any base (2-16)
**
** Parameters:
**   str      - String to convert (e.g., "-1A", "101", "77")
**   str_base - The base of the number (2=binary, 8=octal, 10=decimal, 16=hex)
**
** Returns:
**   The integer value of the string in the given base
**
** Examples:
**   ft_atoi_base("101", 2)    → 5    (binary: 1×4 + 0×2 + 1×1 = 5)
**   ft_atoi_base("FF", 16)    → 255  (hex: 15×16 + 15×1 = 255)
**   ft_atoi_base("-2A", 16)   → -42  (hex: -(2×16 + 10×1) = -42)
**   ft_atoi_base("77", 8)     → 63   (octal: 7×8 + 7×1 = 63)
**   ft_atoi_base("123", 10)   → 123  (decimal: normal number)
**
** HORNER'S METHOD - Process LEFT to RIGHT:
**   For each digit from left to right:
**   1. Multiply current result by base (shift all digits left)
**   2. Add the new digit value
**
**   Example: "2A3" in base 16 → decimal
**     Step 1: result = 0
**     Step 2: See '2' → result = 0 × 16 + 2 = 2
**     Step 3: See 'A'(10) → result = 2 × 16 + 10 = 42
**     Step 4: See '3' → result = 42 × 16 + 3 = 675
**     Final: 675
**
**   This is equivalent to: 2×16² + 10×16¹ + 3×16⁰ = 512 + 160 + 3 = 675
**   But calculated more efficiently without needing power functions!
*/
int ft_atoi_base(const char *str, int str_base)
{
	int result = 0;  // Accumulates the final number
	int sign = 1;    // Track if negative
	int digit;       // Current digit value
	int i = 0;       // Index to traverse string

	// Step 1: Handle negative sign (only at start)
	if (str[i] == '-')
	{
		sign = -1;
		++i;  // Move past the '-'
	}

	
	// Step 2: Process each character using Horner's method
	// Read LEFT to RIGHT, building the number digit by digit
	while ((digit = get_digit(str[i], str_base)) >= 0)
	{
		// Horner's method: result = result × base + digit
		//   This shifts existing digits left and adds new digit
		result = result * str_base + digit;
		++i;  // Move to next character
	}
	
	// Step 3: Apply sign and return
	return (result * sign);
}
