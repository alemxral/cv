#include "ft_list.h"

/* ft_list_size: count the number of nodes in a linked list using recursion
 * 
 * Approach: Recursive solution
 * - Base case: if list is NULL (empty), return 0
 * - Recursive case: count 1 (current node) + count of remaining nodes
 * 
 * How it works step-by-step:
 * Example list: [A] -> [B] -> [C] -> NULL
 * 
 * Call 1: ft_list_size([A])
 *   → not NULL, return 1 + ft_list_size([B])
 * 
 * Call 2: ft_list_size([B])
 *   → not NULL, return 1 + ft_list_size([C])
 * 
 * Call 3: ft_list_size([C])
 *   → not NULL, return 1 + ft_list_size(NULL)
 * 
 * Call 4: ft_list_size(NULL)
 *   → is NULL, return 0  (base case reached)
 * 
 * Unwinding:
 * Call 3 returns: 1 + 0 = 1
 * Call 2 returns: 1 + 1 = 2
 * Call 1 returns: 1 + 2 = 3
 * 
 * Final result: 3 nodes
 */



// typedef struct    s_list
// {
//     struct s_list *next;
//     void          *data;
// }                 t_list;



int	ft_list_size(t_list *begin_list)
{
    /* Base case: empty list (NULL pointer) */
    if (begin_list == 0)
        return (0);              /* no nodes to count */
    
    /* Recursive case: current node exists */
    else
        return (1 + ft_list_size(begin_list->next));
        /*      ↑   ↑
         *      |   recursively count remaining nodes
         *      count current node (1)
         */
}




// int	ft_list_size(t_list *begin_list)
// {
//     /* Base case: empty list (NULL pointer) */
//     if (begin_list == 0)
//         return (0);              /* no nodes to count */
    
//     /* Recursive case: current node exists */
//     else
//         return (1 + ft_list_size(begin_list->next));
//         /*      ↑   ↑
//          *      |   recursively count remaining nodes
//          *      count current node (1)
//          */
// }