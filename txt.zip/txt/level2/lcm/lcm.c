/* 
 * LCM (Least Common Multiple):
 * The smallest positive integer that is divisible by both a and b.
 * 
 * Mathematical definition:
 * LCM(a, b) = smallest n such that:
 *   - n % a == 0  (n is a multiple of a)
 *   - n % b == 0  (n is a multiple of b)
 * 
 * Examples:
 *   LCM(4, 6) = 12    (multiples of 4: 4,8,12,16... multiples of 6: 6,12,18...)
 *   LCM(3, 5) = 15    (multiples of 3: 3,6,9,12,15... multiples of 5: 5,10,15...)
 *   LCM(12, 18) = 36  (multiples of 12: 12,24,36... multiples of 18: 18,36...)
 *   LCM(7, 7) = 7     (same number)
 *   LCM(1, n) = n     (1 divides everything)
 * 
 * Formula relationship:
 *   LCM(a, b) × GCD(a, b) = a × b
 *   LCM(a, b) = (a × b) / GCD(a, b)
 * 
 * Approach: Brute force
 * - Start from the larger of the two numbers
 * - Keep incrementing until we find a number divisible by both
 * - This is guaranteed to terminate (worst case: a × b)
 */
unsigned int lcm(unsigned int a, unsigned int b)
{
    unsigned int n;	

    /* Edge case: LCM with 0 is undefined (return 0 by convention) */
    if (a == 0 || b == 0)
        return (0);
    
    /* Optimization: start from the larger number
     * (LCM can't be smaller than max(a, b))
     */
    if (a > b)
        n = a;
    else
        n = b;
    
    /* Infinite loop: increment n until we find LCM */
    while (1)
    {
        /* Check if n is divisible by both a and b */
        if (n % a == 0 && n % b == 0)
            return (n);  /* Found the LCM! */
        
        /* Try next number */
        ++n;
    }
}

/*
 * Example trace: lcm(4, 6)
 * 
 * Start: n = 6 (larger of 4 and 6)
 * 
 * Iteration 1: n = 6
 *   6 % 4 = 2 → not 0, continue
 * 
 * Iteration 2: n = 7
 *   7 % 4 = 3 → not 0, continue
 * 
 * Iteration 3: n = 8
 *   8 % 4 = 0 ✓
 *   8 % 6 = 2 → not 0, continue
 * 
 * Iteration 4: n = 9
 *   9 % 4 = 1 → not 0, continue
 * 
 * Iteration 5: n = 10
 *   10 % 4 = 2 → not 0, continue
 * 
 * Iteration 6: n = 11
 *   11 % 4 = 3 → not 0, continue
 * 
 * Iteration 7: n = 12
 *   12 % 4 = 0 ✓
 *   12 % 6 = 0 ✓
 *   Return 12 ← LCM found!
 */