/* 
 * Function: ft_list_push_front
 * 
 * Description:
 * Add a new node at the BEGINNING of the list with the given data.
 * 
 * Parameters:
 * - begin_list: pointer to pointer to the first node (double pointer!)
 * - data: the data to store in the new node
 * 
 * Example:
 * Before: [B] -> [C] -> NULL
 * After calling ft_list_push_front(&list, "A"):
 * After:  [A] -> [B] -> [C] -> NULL
 * 
 * Function prototype:
 */

#include "ft_list.h"
#include <stdlib.h>

void ft_list_push_front(t_list **begin_list, void *data)
{


t_list *new_node;
new_node = malloc(sizeof(t_list));

new_node->data = data;
new_node->next = *begin_list;
*begin_list = new_node;

}