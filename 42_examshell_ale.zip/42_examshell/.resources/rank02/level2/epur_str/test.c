


#include <unistd.h>





void epur(char *str)
{


int i=0;
int one_space_seen=1;


while(str[i]!='\0')
{

if ((str[i]==' ' || str[i]=='\t')&& one_space_seen==0)
{
	write(1," ",1);
	one_space_seen=1;
}

else if (str[i]!=' ' && str[i]!='\t')
{
	write(1,&str[i],1);
	one_space_seen=0;
}

i++;
}

write(1,"\n",1);
}



int main(int argc, char **argv)
{


if(argc!=2)
{
    write(1,"\n",1);
    return 0;}

else
{


epur(argv[1]);
return 1;
}

}
