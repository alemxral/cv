


#include <unistd.h>


void ft_putnbr(int n)
{ 

char digit;

if(n>9)
{
        ft_putnbr(n/10);

}

 

digit = n%10 + '0';
write(1,&digit,1); 




return;

}


int is_prime(int n)
{

int i=2;

if (n==1)
{

return 0;

}

if(n==2)
{
return 1;
}

while(i<=n/2)
{

	if(n%i==0)
	{
	return 0;
	}


i++;
}

return 1;

}


void add_prime_sum(int num)
{

int i = 0;
int result = 0;

while(i<=num)
{

	if (is_prime(i))
	{
	
	result = result + i;
	
	}


i++;
}

ft_putnbr(result);
write(1,"\n",1);
}



int main(int argc, char **argv)
{


if(argc!=2)
{
    write(1,"\n",1);
    return 0;}

else
{

int i = 0;
int digit = 0;

while(argv[1][i]!='\0')
{


digit = digit*10 +(argv[1][i] - '0');
i++;

}


add_prime_sum(digit);
return 1;
}

}
