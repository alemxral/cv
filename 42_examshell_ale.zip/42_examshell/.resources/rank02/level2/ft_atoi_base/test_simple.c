/*
** ft_atoi_base: Convert a string from any base (2-16) to decimal integer
**
** Examples:
**   ft_atoi_base("101", 2)     → 5     (binary)
**   ft_atoi_base("FF", 16)     → 255   (hex)
**   ft_atoi_base("-2A", 16)    → -42   (negative hex)
**   ft_atoi_base("123", 10)    → 123   (decimal)
**   ft_atoi_base("77", 8)      → 63    (octal)
*/

// Helper: Convert a character to its numeric value (0-15)
// Returns -1 if invalid
int char_to_digit(char c)
{
	if (c >= '0' && c <= '9')
		return (c - '0');           // '0'→0, '1'→1, ..., '9'→9
	if (c >= 'a' && c <= 'f')
		return (10 + c - 'a');      // 'a'→10, 'b'→11, ..., 'f'→15
	if (c >= 'A' && c <= 'F')
		return (10 + c - 'A');      // 'A'→10, 'B'→11, ..., 'F'→15
	return (-1);                    // Invalid character
}

int ft_atoi_base(const char *str, int str_base)
{
	int result = 0;
	int sign = 1;
	int digit;

	// Step 1: Handle negative sign (only at start)
	if (*str == '-')
	{
		sign = -1;
		str++;          // Move past the '-'
	}

	// Step 2: Process each character using Horner's method
	while (*str)
	{
		digit = char_to_digit(*str);
		
		// Stop if invalid character or digit >= base
		if (digit == -1 || digit >= str_base)
			break;
		
		// Horner's method: shift left and add new digit
		// Example: "2A" in base 16
		//   First '2':  result = 0 × 16 + 2 = 2
		//   Then 'A':   result = 2 × 16 + 10 = 42
		result = result * str_base + digit;
		
		str++;
	}

	// Step 3: Apply sign
	return (result * sign);
}

// Test program
#include <stdio.h>

int main(void)
{
	// Test cases
	printf("Binary:\n");
	printf("  '101' base 2 = %d (expected 5)\n", ft_atoi_base("101", 2));
	printf("  '1111' base 2 = %d (expected 15)\n", ft_atoi_base("1111", 2));
	
	printf("\nOctal:\n");
	printf("  '77' base 8 = %d (expected 63)\n", ft_atoi_base("77", 8));
	printf("  '100' base 8 = %d (expected 64)\n", ft_atoi_base("100", 8));
	
	printf("\nDecimal:\n");
	printf("  '123' base 10 = %d (expected 123)\n", ft_atoi_base("123", 10));
	printf("  '-42' base 10 = %d (expected -42)\n", ft_atoi_base("-42", 10));
	
	printf("\nHexadecimal:\n");
	printf("  'FF' base 16 = %d (expected 255)\n", ft_atoi_base("FF", 16));
	printf("  '2A' base 16 = %d (expected 42)\n", ft_atoi_base("2A", 16));
	printf("  '-2a' base 16 = %d (expected -42)\n", ft_atoi_base("-2a", 16));
	printf("  '12FDB3' base 16 = %d (expected 1244595)\n", ft_atoi_base("12FDB3", 16));
	printf("  '12fdb3' base 16 = %d (expected 1244595)\n", ft_atoi_base("12fdb3", 16));
	
	printf("\nBase 4:\n");
	printf("  '123' base 4 = %d (expected 27)\n", ft_atoi_base("123", 4));
	
	printf("\nInvalid characters (should stop):\n");
	printf("  '12G' base 16 = %d (expected 18, stops at G)\n", ft_atoi_base("12G", 16));
	printf("  '129' base 8 = %d (expected 10, stops at 9)\n", ft_atoi_base("129", 8));
	
	return (0);
}
