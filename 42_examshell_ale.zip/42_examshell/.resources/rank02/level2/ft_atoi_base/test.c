#include <unistd.h>


void ft_putnbr(int n)
{ 

char digit;

if(n>9)
{
        ft_putnbr(n/10);

}

 

digit = n%10 + '0';
write(1,&digit,1); 


return;

}


int position(char str)
{

char base[]="0123456789ABCDEF";

int i = 0;


while(base[i]!=str)
{

i++;

}



return(i);


}


int power(int base, int exponent)
{
    int result = 1;
    int i = 0;
    
    while (i < exponent)
    {
        result = result * base;
        i++;
    }
    return result;
}







int	ft_atoi_base(const char *str, int str_base)
{
    int len = 0;
    while (str[len])
        len++;
    
    int result = 0;
    int i = 0;
    
    while (i < len)
    {
        int digit = position(str[i]);
        int pos = len - 1 - i;  // Position from right (rightmost = 0)
        
        result = result + digit * power(str_base, pos);
        i++;
    }
    
    return result;
}

int main(int argc, char **argv)
{


if(argc!=3)
{
    write(1,"\n",1);
    return 0;}

else
{

int i = 0;


int base = 0;
while(argv[2][i]!='\0')
{


base = base*10 +(argv[2][i] - '0');
i++;

}




ft_putnbr(ft_atoi_base(argv[1],base));
write(1,"\n",1);



return 1;
}

}
