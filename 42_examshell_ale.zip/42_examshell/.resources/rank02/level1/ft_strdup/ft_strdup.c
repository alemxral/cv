#include <stdlib.h>
#include <stdio.h>

/* ft_strdup: duplicate a string by allocating memory and copying
 * - measure the length of src
 * - allocate memory for a copy (length + 1 for '\0')
 * - copy all characters from src to dest
 * - null-terminate dest
 * - return pointer to the new string (caller must free it)
 * - return NULL if malloc fails
 */
char    *ft_strdup(char *src)
{
    int	i;
    char *dest;

    /* measure length of src */
    i = 0;
    while (src[i] != '\0')
        i++;
    
    /* allocate memory for i characters + '\0' */
    dest = malloc(sizeof (char) * (i + 1));
    if (dest == NULL)       /* check if malloc failed */
        return (NULL);
    
    /* copy each character from src to dest */
    i = 0;
    while (src[i] != '\0')
    {
        dest[i] = src[i];
        i++;
    }
    
    /* copy the null terminator */
    dest[i] = src[i];       /* src[i] is '\0' here */
    
    return (dest);          /* return pointer to duplicated string */
}
