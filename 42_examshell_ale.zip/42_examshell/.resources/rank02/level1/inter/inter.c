#include <unistd.h>

/* inter: print characters that appear in both s1 and s2, in order of s1, without duplicates
 * - iterate through each character in s1
 * - for each char, check if it appears in s2
 * - if yes, check if it's the first occurrence in s1 (no duplicate printing)
 * - if yes, check if it's the first occurrence in s2 (optional extra check from original code)
 * - if all checks pass, print the character once
 */
int	main(int ac, char **av)
{
    int	i;          /* index for iterating through s1 */
    int k;          /* index for iterating through s2 */
    int l;          /* helper index for checking first occurrence */
    char *s1;       /* first string argument */
    char *s2;       /* second string argument */

    i = 0;
    l = 0;
    if (ac == 3)    /* require exactly 2 arguments (plus program name) */
    {
        s1 = av[1]; /* pointer to first argument string */
        s2 = av[2]; /* pointer to second argument string */
        
        /* iterate through each character of s1 */
        while (s1[i] != '\0')
        {
            k = 0;
            /* check if current s1[i] exists anywhere in s2 */
            while (s2[k] != '\0')
            {
                if(s1[i] == s2[k])  /* found a match in s2 */
                { 
                    /* check if s1[i] is the first occurrence of this char in s1 */
                    l = 0;
                    while (s1[l] != s1[i])  /* scan s1 until we find s1[i] */
                        l++;
                    if (l == i)             /* if found at index i, it's the first occurrence */
                    {
                        /* (optional) check if s2[k] is first occurrence in s2 */
                        l = 0;
                        while (s2[l] != s2[k])  /* scan s2 until we find s2[k] */
                            l++;
                        if (l == k)             /* if found at index k, it's first in s2 */
                            write(1, &s1[i], 1); /* print the character once */
                    }
                }
                k++;
            }
            i++;
        }
    }
    write(1, "\n", 1);  /* always print newline at the end */
}


// more simple version without optional second check:

// #include <unistd.h>

// /* inter: print characters that appear in both s1 and s2, in order of s1, without duplicates
//  * - use a "seen" array to track which characters we've already printed
//  * - iterate through s1, check if each char exists in s2
//  * - if yes and not printed before, print it and mark as seen
//  */
// int main(int ac, char **av)
// {
//     int i;
//     int j;
//     unsigned char seen[256] = {0};  /* track printed chars (0=not seen, 1=seen) */
    
//     if (ac == 3)    /* require exactly 2 arguments */
//     {
//         i = 0;
//         /* iterate through each character of s1 */
//         while (av[1][i] != '\0')
//         {
//             /* check if current char exists in s2 */
//             j = 0;
//             while (av[2][j] != '\0')
//             {
//                 if (av[1][i] == av[2][j])   /* found match in s2 */
//                 {
//                     /* check if we haven't printed this char yet */
//                     if (!seen[(unsigned char)av[1][i]])
//                     {
//                         write(1, &av[1][i], 1);         /* print it */
//                         seen[(unsigned char)av[1][i]] = 1;  /* mark as seen */
//                     }
//                     break;  /* no need to keep searching s2 */
//                 }
//                 j++;
//             }
//             i++;
//         }
//     }
//     write(1, "\n", 1);
//     return 0;
// }