/* ft_strrev: reverse a string in place
 * - measure the length of the string
 * - swap characters from both ends moving toward the center
 * - stop when we reach the middle
 * - return the reversed string
 */
char *ft_strrev(char *str)
{
    int len = 0;
    int i = 0;
    char temp;

    /* measure length of string */
    while (str[len] != '\0')
    {
        len++;
    }

    /* swap characters: first with last, second with second-to-last, etc. */
    while (i < len / 2)
    {
        temp = str[i];                      /* save first character */
        str[i] = str[len - 1 - i];          /* replace first with last */
        str[len - 1 - i] = temp;            /* put saved char at end */
        i++;                                /* move toward center */
    }

    return (str);                           /* return reversed string */
}
