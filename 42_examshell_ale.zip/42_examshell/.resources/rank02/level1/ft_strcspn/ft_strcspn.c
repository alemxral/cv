#include <unistd.h>
#include <stdio.h>
#include <string.h>

/* ft_strcspn: return the length of the initial segment of s
 * which consists entirely of characters NOT in reject
 * - scan s from left to right
 * - for each character in s, check if it appears in reject
 * - if found, return the current index (length of segment)
 * - if end of s is reached without finding any reject char, return full length
 */
size_t  ft_strcspn(const char *s, const char *reject)
{
	size_t	i;
	size_t	k;

	i = 0;                          /* index in s */
	k = 0;                          /* index in reject */
	while (s[i] != '\0')            /* scan each character in s */
	{
		while (reject[k] != '\0')   /* check current s[i] against all reject chars */
		{
			if (reject[k] == s[i])  /* if s[i] is in reject, return length so far */
				return (i);
			k++;
		}
		k = 0;                      /* reset reject index for next s character */
		i++;                        /* move to next character in s */
	}
	return (i);                     /* no reject char found; return full length */
}
