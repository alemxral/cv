#include "ft_list.h"

/*
** sort_list: Sorts a linked list using bubble sort algorithm
**
** Parameters:
**   lst - pointer to first node of the list
**   cmp - comparison function that returns 0 if elements should be swapped
**         (typically: returns 0 if first > second for ascending order)
**
** Returns:
**   Pointer to the head of the sorted list
**
** Algorithm: Bubble sort
**   - Repeatedly traverse the list
**   - Compare adjacent elements using cmp function
**   - Swap if cmp returns 0 (elements are out of order)
**   - Reset to beginning after each swap to ensure full sort
*/
t_list	*sort_list(t_list *lst, int (*cmp)(int, int))
{
	int	swap;
	t_list	*tmp;

	/* Save pointer to head of list */
	tmp = lst;
	
	/* Traverse list until we reach the last node */
	while(lst->next != NULL)
	{
		/* Compare current node with next node using cmp function */
		/* If cmp returns 0, elements are out of order and need swapping */
		if (cmp(lst->data, lst->next->data) == 0)
		{
			/* Swap data between current and next node */
			swap = lst->data;
			lst->data = lst->next->data;
			lst->next->data = swap;
			
			/* Reset to beginning to ensure complete sort */
			/* (bubble sort needs multiple passes) */
			lst = tmp;
		}
		else
			/* Elements in correct order, move to next node */
			lst = lst->next;
	}
	
	/* Restore pointer to head of list */
	lst = tmp;
	return (lst);
}