/*
** FT_SPLIT - Split string by whitespace into array of words
** 
** Function: char **ft_split(char *str)
** 
** Splits a string into an array of words (separated by spaces, tabs, newlines).
** 
** Example:
**   Input:  "Hello   world\t\tfrom\n42"
**   Output: ["Hello", "world", "from", "42", NULL]
** 
** Return: Array of strings (words), NULL-terminated
** 
** Algorithm:
** 1. Count number of words
** 2. Allocate array of pointers (size = words + 1 for NULL)
** 3. For each word: allocate memory and copy it
** 4. Return the array
*/

#include <stdlib.h>

/*
** ft_wordlen: Calculate length of current word
** 
** Parameters:
**   str - pointer to start of word
** 
** Returns:
**   Length of word (stops at whitespace or end of string)
** 
** Example:
**   "Hello world" → returns 5
**   "42\n"        → returns 2
*/
int	ft_wordlen(char *str)
{
	int i = 0;

	/* Count characters until whitespace or end */
	while (str[i] != '\0' && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
	{
		++i;
	}
	return (i);
}

/*
** word_dupe: Duplicate a single word from string
** 
** Parameters:
**   str - pointer to start of word
** 
** Returns:
**   Allocated string containing the word (must be freed later)
** 
** How it works:
**   1. Calculate word length
**   2. Allocate memory (length + 1 for null terminator)
**   3. Copy characters
**   4. Add null terminator
** 
** Example:
**   Input: "Hello world" (pointer at 'H')
**   Output: "Hello" (new allocated string)
** 
** ++i vs i++ comparison:
**   ++i (pre-increment):  Increments FIRST, then returns new value
**   i++ (post-increment): Returns current value FIRST, then increments
** 
**   In this loop context, both work identically because:
**   - We don't use the return value of the increment
**   - The increment happens at the end of the loop iteration
** 
**   Examples:
**     while (i < len) { word[i] = str[i]; ++i; }  // Pre-increment (slightly faster)
**     while (i < len) { word[i] = str[i]; i++; }  // Post-increment (same result)
**     word[i++] = str[i];  // Would be WRONG! Uses i, THEN increments
**     word[++i] = str[i];  // Would be WRONG! Increments, THEN uses (skips index 0)
** 
**   Performance: ++i is marginally faster (no need to save old value)
**   Readability: Both are clear in this context
**   Convention: ++i is preferred in loops when value isn't used
*/
char	*word_dupe(char *str)
{
	int i = 0;
	int len = ft_wordlen(str);          /* Get word length */
	char *word = malloc(sizeof(char) * (len + 1));  /* Allocate memory */
	
	word[len] = '\0';  /* Null-terminate the string */
	
	/* Copy characters one by one */
	while (i < len)
	{
		word[i] = str[i];
		++i;  /* Pre-increment: faster and conventional for loops */
		// i++; would work identically here
	}
	return (word);
}

/*
** fill_words: Fill array with duplicated words from string
** 
** Parameters:
**   array - array of char* to fill (must be pre-allocated)
**   str   - source string to split
** 
** How it works:
**   1. Skip leading whitespace
**   2. For each word:
**      a. Duplicate the word into array[index]
**      b. Skip past the word
**      c. Skip trailing whitespace before next word
**   3. Repeat until end of string
** 
** Example trace for "Hello  world":
**   1. Skip nothing (no leading whitespace)
**   2. array[0] = word_dupe("Hello  world") → "Hello"
**   3. Skip "Hello" (5 chars)
**   4. Skip "  " (2 spaces)
**   5. array[1] = word_dupe("world") → "world"
**   6. Skip "world" (5 chars)
**   7. End of string
*/
void	fill_words(char **array, char *str)
{
	int word_index = 0;  /* Current position in array */
	int i = 0;
	
	/* Skip leading whitespace */
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
	{
		++i;
	}
	
	/* Process each word */
	while (str[i] != '\0')
	{
		/* Duplicate current word into array */
		array[word_index] = word_dupe(&str[i]);
		++word_index;
		
		/* Skip past this word (move to whitespace or end) */
		while (str[i] != '\0' && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
		{
			++i;
		}
		
		/* Skip whitespace before next word */
		while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
		{
			++i;
		}
	}
}

/*
** count_words: Count number of words in string
** 
** Parameters:
**   str - string to analyze
** 
** Returns:
**   Number of words (separated by whitespace)
** 
** A "word" is any sequence of non-whitespace characters.
** 
** Example:
**   "Hello   world\t42" → 3 words
**   "  \t\n "           → 0 words
**   "42"                → 1 word
** 
** How it works:
**   1. Skip leading whitespace
**   2. For each word found:
**      a. Increment counter
**      b. Skip the word
**      c. Skip trailing whitespace
**   3. Return counter
*/
int		count_words(char *str)
{
	int num_words = 0;
	int i = 0;
	
	/* Skip leading whitespace */
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
	{
		++i;
	}
	
	/* Count each word */
	while (str[i] != '\0')
	{
		++num_words;  /* Found a word */
		
		/* Skip past this word */
		while (str[i] != '\0' && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
		{
			++i;
		}
		
		/* Skip whitespace after word */
		while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
		{
			++i;
		}
	}
	return (num_words);
}

/*
** ft_split: MAIN FUNCTION - Split string into array of words
** 
** Parameters:
**   str - string to split
** 
** Returns:
**   Array of strings (char **), NULL-terminated
**   Each string is a word from the input
**   Caller must free the array and each string
** 
** Example:
**   Input: "Hello  world\t42"
**   Output: ["Hello", "world", "42", NULL]
**           array[0] → "Hello"
**           array[1] → "world"
**           array[2] → "42"
**           array[3] → NULL
** 
** Memory allocation:
**   - One allocation for the array of pointers
**   - One allocation per word (done in word_dupe)
**   - Total: (num_words + 1) allocations
** 
** Steps:
**   1. Count words in string
**   2. Allocate array of pointers (size = num_words + 1)
**   3. Set last element to NULL (array terminator)
**   4. Fill array with duplicated words
**   5. Return the array
*/
char	**ft_split(char *str)
{
	int		num_words;
	char	**array;
	
	/* Step 1: Count how many words we'll have */
	num_words = count_words(str);
	
	/* Step 2: Allocate array of pointers (+1 for NULL terminator) */
	array = malloc(sizeof(char *) * (num_words + 1));
	//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	//      Array of pointers: [ptr1, ptr2, ..., ptrN, NULL]
	
	/* Step 3: NULL-terminate the array */
	array[num_words] = 0;  /* Last element is NULL */
	
	/* Step 4: Fill array with words */
	fill_words(array, str);
	
	/* Step 5: Return the array */
	return (array);
}
