


















#include <stdio.h>
#include <stdlib.h>


int count_words(char *str)
{

int i=0;
int num_words=0;

while (str[i]==' ' || str[i]=='\t' || str[i]=='\n')
    {
        ++i;
    }

while(str[i]!='\0')
    {
        ++num_words;


        // Skip past this word

        while (str[i]!='\0' && str[i]!=' ' && str[i]!='\t' && str[i]!='\n')
        {
            ++i;
        }


        // Skip whitespace after word
        while (str[i]==' ' || str[i]=='\t' || str[i]=='\n')
        {
            ++i;
        }
    }

return(num_words);

}

wchar **arr, char *str)


fill_words(char **arr, char *str)
{

int i=0;
int word_count=0;

while(str[i]==' ' || str[i]=='\t' || str[i]=='\n')
    {
        ++i;
    }

while(str[i]!='\0')
    {

       arr[word_count]=word_dupe(&str[i]);
       word_count++;


        // Skip past this word

        while (str[i]!='\0' && str[i]!=' ' && str[i]!='\t' && str[i]!='\n')
        {
            ++i;
        }



        // Skip whitespace after word
        while (str[i]==' ' || str[i]=='\t' || str[i]=='\n')
        {
            ++i;

        }
       
    }





}



char    **dsplit(char *str)
{

// count words    
int len=count_words(str);
char **arr;

//allocate memory for array of strings
arr=malloc((len+1)*sizeof(char *));

//include null terminator
arr[len]=0;


//fill array with words

fill_words(arr, str);

//return array
return(arr);

}




int main(int argc, char **argv)
{
    /* Check if exactly one argument provided */
    if (argc == 2)
    {
        int i = 0;
        
     char **split=   dsplit(argv[1]);



    /* Print first word (always exists, even if empty string) */
	printf("%s ", split[0]);


     while(split[i]!=0)
     {
        printf("%s ", split[i]);
        i++;
     }

    }

    printf("\n");
    return (0);
}
