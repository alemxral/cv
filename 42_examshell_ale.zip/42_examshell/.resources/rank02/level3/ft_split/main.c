/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/06 15:58:50 by pandalaf          #+#    #+#             */
/*   Updated: 2022/11/06 15:59:01 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
** TEST PROGRAM FOR ft_split
** 
** ft_split splits a string by whitespace characters (space, tab, newline)
** and returns an array of strings (words).
** 
** Example:
**   Input:  "Hello   world\t\tfrom\n42"
**   Output: ["Hello", "world", "from", "42", NULL]
** 
** This main tests the function by:
** 1. Taking a string as command-line argument
** 2. Splitting it with ft_split
** 3. Printing each word separated by spaces
*/

#include <stdlib.h>
#include <stdio.h>

/* Function prototype: ft_split defined elsewhere (ft_split.c) */
char	**ft_split(char *str);

int main(int argc, char **argv)
{
	char	**split;  /* Array of strings (result of ft_split) */
	int		i;        /* Index for iterating through array */

	/* Check if exactly one argument provided */
	if (argc == 2)
	{
		/* Split the input string into words */
		split = ft_split(argv[1]);
		//      ^^^^^^^^^^^^^^^^^^
		//      Returns array: ["word1", "word2", ..., NULL]
		
		/* Print first word (always exists, even if empty string) */
		printf("%s ", split[0]);
		
		/* Print remaining words */
		i = 1;
		while (split[i] != 0)  /* NULL terminates the array */
		{
			printf("%s ", split[i]);
			i++;
		}
		
		/* Print the NULL element (prints nothing, but included for completeness) */
		printf("%s", split[i]);  /* split[i] is NULL here */
	}
	
	/* Always print newline at end */
	printf("\n");
	
	return (0);
}
