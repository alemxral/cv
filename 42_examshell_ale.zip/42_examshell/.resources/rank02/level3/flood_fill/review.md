

1.




  void  flood_fill(char **tab, t_point size, t_point begin);

  we add the target

this is what will be replaced by F 
char target = tab[begin.y][begin.x]

we pass this to the helper fun

  void  flood_fill(char **tab, t_point size, t_point cur, char to_fill);

  if(cur.x<0 || cur.x>=size.x || cur.y<0 || cur.y>= size.y || tab[cur.y][cur.x]!=to_fill )
     return;

tab[cur.y][cur.x]='F';

fill(tab,size,(t_point){cur.x-1, cur.y},to_fill)
fill(tab,size,(t_point){cur.x+1, cur.y},to_fill)
fill(tab,size,(t_point){cur.x, cur.x+y},to_fill)
fill(tab,size,(t_point){cur.x, cur.x-y},to_fill)







2.




void	flood_fill(char **tab, t_point size, t_point begin)
{

char target = tab[begin.y][begin.x];

fill(tab,size,cur,target);

}

void	fill(char **tab, t_point size, t_point cur, char to_fill)

{


if(cur.y<0||cur.y>=size.y ||cur.x<0||cur.x>=size.x ||tab[cur.y][cur.x]!=to_fill )
 return;


tab[cur.y][cur.x]='F';



fill(tab,size,(t_point){cur.x+1,cur.y},to_fill )
fill(tab,size,(t_point){cur.x-1,cur.y},to_fill )
fill(tab,size,(t_point){cur.x,cur.y+1},to_fill )
fill(tab,size,(t_point){cur.x,cur.y-1},to_fill )


}



typedef struct 	s_point {
	int			x;				// x : Width  | x-axis | column
	int			y;				// y : Height | y-axis | row
}				t_point;




void	flood_fill(char **tab, t_point size, t_point begin)
{


char target=tab[begin.y][begin.x];


fill(tab,size,begin,target);


}



void	fill(char **tab, t_point size, t_point cur, char to_fill)

{


if(cur.x<0||cur.x>=size.x || cur.y<0||cur.y>=size.y || tab[cur.y][cur.x]!=to_fill)
    return;


tab[cur.y][cur.x]!='F'


fill(tab,size,(t_point){cur.x+1,},to_fill)
fill(tab,size,(t_point){cur.x+1,},to_fill)
fill(tab,size,(t_point){cur.x+1,},to_fill)
fill(tab,size,(t_point){cur.x+1,},to_fill)


}




