/*
** FLOOD FILL ALGORITHM
** 
** Problem: Given a 2D grid and a starting point, fill all connected cells
** that have the same character as the starting point with 'F'.
** 
** Example:
**   Before (start at position 1,1 which is '0'):
**   1 1 1 1
**   1 0 0 1
**   1 0 1 1
**   
**   After flood_fill:
**   1 1 1 1
**   1 F F 1
**   1 F 1 1
**   
** How it works:
** 1. Start at given position
** 2. Mark current cell as 'F'
** 3. Recursively fill all 4 adjacent cells (up, down, left, right)
**    that have the same original character
** 4. Stop when hitting boundaries or different characters
*/

typedef struct 	s_point {
	int			x;				// x : Width  | x-axis | column
	int			y;				// y : Height | y-axis | row
}				t_point;

/*
** fill: HELPER FUNCTION (internal, does the recursive work)
** 
** Parameters:
**   tab      - 2D character array (the grid to fill)
**   size     - Dimensions of the grid (size.x = width, size.y = height)
**   cur      - Current position being processed
**   to_fill  - The target character we're looking for (to replace with 'F')
** 
** This function has 4 parameters because it needs to know WHAT character
** to fill on every recursive call.
** 
** How it works:
**   1. Check if out of bounds → return (stop)
**   2. Check if current cell != target character → return (stop)
**   3. Mark current cell as 'F'
**   4. Recursively call fill on 4 adjacent cells (left, right, up, down)
*/
void	fill(char **tab, t_point size, t_point cur, char to_fill)
{
	// BASE CASES (stop conditions):
	// - Out of bounds vertically: cur.y < 0 or cur.y >= size.y
	// - Out of bounds horizontally: cur.x < 0 or cur.x >= size.x
	// - Current cell is not the target character
	if (cur.y < 0 || cur.y >= size.y || cur.x < 0 || cur.x >= size.x
		|| tab[cur.y][cur.x] != to_fill)
		return;

	// RECURSIVE CASE:
	// Mark current cell as filled
	tab[cur.y][cur.x] = 'F';
	
	// Fill adjacent cells in 4 directions
	// (t_point){x, y} creates a new point struct inline
	fill(tab, size, (t_point){cur.x - 1, cur.y}, to_fill);  // Left
	fill(tab, size, (t_point){cur.x + 1, cur.y}, to_fill);  // Right
	fill(tab, size, (t_point){cur.x, cur.y - 1}, to_fill);  // Up
	fill(tab, size, (t_point){cur.x, cur.y + 1}, to_fill);  // Down
}

/*
** flood_fill: PUBLIC FUNCTION (the one main() calls)
** 
** Parameters:
**   tab   - 2D character array (the grid to fill)
**   size  - Dimensions of the grid
**   begin - Starting position for the flood fill
** 
** This function has only 3 parameters (matching the required signature).
** It extracts the character at the starting position and passes it
** to the helper function fill().
** 
** Why this design?
**   - The exam requires flood_fill to have 3 parameters
**   - But the recursive algorithm needs to know the target character
**   - Solution: Use a wrapper (flood_fill) that extracts the target
**     and calls a helper (fill) that does the actual recursive work
*/
void	flood_fill(char **tab, t_point size, t_point begin)
{
	// Extract the character at starting position
	// This is what we'll be filling (replacing with 'F')
	char target = tab[begin.y][begin.x];
	
	// Call the helper function with the target character
	fill(tab, size, begin, target);
	//                     ^^^^^^ Pass the target to helper
	
	// Compact version (same thing):
	// fill(tab, size, begin, tab[begin.y][begin.x]);
}
