




void ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)(void *, void *))
{



t_list *cur=*begin_list;





    if(cmp(cur->data,data_ref)==0)
    {

        *begin_list=cur ->next;

        free(cur);

        ft_list_remove(begin_list,data_ref,cmp)

    }


    else
    {

         ft_list_remove(&cur->next,data_ref,cmp)
    }


}





void ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)(void *, void *))
{



t_list *cur=*begin_list; pointer to list




if(cmp(curr->data,data_ref)==0)

    *begin_list=cur->next;
    free(cur);
    ft_list_remove_if(begin_list,data_ref,cmp)


else

    ft_list_remove_if(&cur->next,data_ref,cmp)



}












void ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)());
{



// STEP 1: Base case - empty list or NULL pointer

// STEP 2: Get current node to examine

// STEP 3: Compare current node's data with data_ref


// STEP 4a: MATCH found - remove this node


// STEP 4b: NO MATCH - keep current node, check rest of list











}