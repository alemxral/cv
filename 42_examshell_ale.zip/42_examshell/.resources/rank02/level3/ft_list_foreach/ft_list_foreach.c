#include <stdlib.h>
#include "ft_list.h"

// Iterates through a linked list and applies function f to each node's data
// begin_list: pointer to the first node of the list
// f: function pointer that takes void* and returns void
//
// ALGORITHM STEPS:
// 1. Initialize pointer to start of list
// 2. Loop while pointer is not NULL
// 3. Apply function f to current node's data
// 4. Move to next node and repeat
void	ft_list_foreach(t_list *begin_list, void (*f)(void *))
{
	t_list *list_ptr;

	// STEP 1: Initialize - start at the beginning of the list
	list_ptr = begin_list;
	
	// STEP 2: Loop condition - traverse until we reach NULL (end of list)
	while (list_ptr)
	{
		// STEP 3: Apply function f to the current node's data
		// f could be any function: print, modify, count, etc.
		(*f)(list_ptr->data);
		
		// STEP 4: Move to next node (advance iterator)
		list_ptr = list_ptr->next;
		// Then loop back to STEP 2 to check if we reached the end
	}
}