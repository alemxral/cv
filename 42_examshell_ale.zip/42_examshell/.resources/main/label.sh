source colors.sh
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "███████╗██╗  ██╗ █████╗ ███╗   ███╗"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "██╔════╝╚██╗██╔╝██╔══██╗████╗ ████║"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "█████╗   ╚███╔╝ ███████║██╔████╔██║"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "██╔══╝   ██╔██╗ ██╔══██║██║╚██╔╝██║"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "███████╗██╔╝ ██╗██║  ██║██║ ╚═╝ ██║"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝"
printf   "${BOLD}${WHITE}%s${RESET}\n" " 42 Practice Test Level & Real Mode"