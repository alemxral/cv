


int  max(int* tab, unsigned int len);
{


if (len==0) {return 0;}



int max = tab[0];


while(tab[i])
{

if (tab[i]>max)

{

max = tab[i];

}

i++;
}

return max;

}



int main(void)

{



int array[]=(1,2,3,4,5,6,7,8);






}










