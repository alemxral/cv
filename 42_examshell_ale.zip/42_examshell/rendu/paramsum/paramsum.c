#include <unistd.h>

/* putnbr: print a positive integer to stdout using recursion
 * - if n >= 10, recursively print all digits except the last one (n / 10)
 * - then print the last digit (n % 10) by converting it to a char ('0' + digit)
 * - this ensures digits are printed left-to-right (most significant first)
 */
void putnbr(int n) {
    if (n >= 10) {              /* if more than one digit */
        putnbr(n / 10);         /* recursively print higher digits first */
    }
    char c = '0' + (n % 10);    /* convert last digit to ASCII character */
    write(1, &c, 1);            /* write that digit to stdout */
}

int main(int argc, char **argv) {
    (void)argv;                 /* silence unused parameter warning */
    putnbr(argc - 1);           /* print the number of arguments (excluding program name) */
    write(1, "\n", 1);          /* print newline */
    return 0;
}
